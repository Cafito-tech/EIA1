 <!DOCTYPE html>
 <html> 
 <body bgcolor = #FBFBEF </body>
 <head> 
  <h1>  Mein Portfolio  </h1> 
  <i> <b> Willkommen in meiner Welt  </b> </i>
 </head>
 
 <body>
<br> </br>
  <img src= "HTML/foto1.jpg"
  width= "100%" height= "50%" />
  
  <img src= "HTML/foto2.jpg"
  width= "100%" height= "50%" />
  <a href="http:// https://cafito-tech.github.io/Portfolio/  /"><img src="HTML/foto1.jpg" alt="foto1_Big" border="0"></a>
  
  <img src= "HTML/foto3.jpg"
  width= "100%" height= "50%" />
  
  <img src= "HTML/foto4.jpg"
  width= "100%" height= "50%" />
  
  <p> Impressionen </p>
  <img src= "HTML/clip1.mp4.gif" 
  width="100%" height="50%"/>
  <img src= "HTML/clip2.mp4.gif" 
  width="100%" height="50%"/>
  <img src= "HTML/clip3.mp4.gif"
 width="100%" height="50%" />
  <img src= "HTML/clip4.mp4.gif" 
  width="100%" height="50%"/>
  
 </body>
 
 <footer>
 <p>  Viviana Caffo / 78120 Furtwangen / viviana.alfaro@hs-furtwangen.de </p>
 </footer>
 </html>
 
